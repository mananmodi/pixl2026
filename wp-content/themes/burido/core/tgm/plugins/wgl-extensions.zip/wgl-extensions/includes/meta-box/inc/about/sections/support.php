<?php defined( 'ABSPATH' ) || die ?>

<div id="support" class="gt-tab-pane">
	<p class="about-description">
		<?php
		$allowed_html = [
			'a' => [
				'href' => [],
			],
		];
		// Translators: %s - link to documentation.
		echo wp_kses( sprintf( __( 'Still need help with Meta Box? We offer excellent support for you. But don\'t forget to check our <a href="%s">documentation</a> first.', 'wgl-extensions' ), 'https://docs.metabox.io?utm_source=dashboard&utm_medium=link&utm_campaign=meta_box' ), $allowed_html );
		?>
	</p>
	<div class="two">
		<div class="col">
			<h3><?php esc_html_e( 'Free Support', 'wgl-extensions' ); ?></h3>
			<p><?php esc_html_e( 'If you have any question about how to use the plugin, please open a new topic on WordPress.org support forum or open a new issue on Github (preferable). We will try to answer as soon as we can.', 'wgl-extensions' ); ?><p>
			<p><a class="button" target="_blank" href="https://github.com/wpmetabox/meta-box/issues"><?php esc_html_e( 'Go to Github', 'wgl-extensions' ); ?> &rarr;</a></p>
			<p><a class="button" target="_blank" href="https://wordpress.org/support/plugin/meta-box"><?php esc_html_e( 'Go to WordPress.org', 'wgl-extensions' ); ?> &rarr;</a></p>
		</div>

		<div class="col">
			<h3><?php esc_html_e( 'Premium Support', 'wgl-extensions' ); ?></h3>
			<p><?php esc_html_e( 'For users that have bought premium extensions, the support is provided in the Meta Box Support forum. Any question will be answered with technical details within 24 hours.', 'wgl-extensions' ); ?><p>
			<p><a class="button" target="_blank" href="https://support.metabox.io/?utm_source=dashboard&utm_medium=link&utm_campaign=meta_box"><?php esc_html_e( 'Go to support forum', 'wgl-extensions' ); ?> &rarr;</a></p>
		</div>
	</div>
</div>
