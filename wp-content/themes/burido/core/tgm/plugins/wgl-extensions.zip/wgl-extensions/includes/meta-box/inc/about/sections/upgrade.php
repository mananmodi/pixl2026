<?php defined( 'ABSPATH' ) || die ?>

<div class="upgrade">
	<h3><span class="dashicons dashicons-awards"></span> <?php esc_html_e( 'Upgrade to Meta Box PRO', 'wgl-extensions' ); ?></h3>
	<p><?php esc_html_e( 'Please upgrade to the PRO plan to unlock more awesome features.', 'wgl-extensions' ); ?></p>
	<ul>
		<li><svg class="icon"><use xlink:href="#checkmark-outline"></use></svg><?php esc_html_e( 'Create custom fields with drag-n-drop interface - no coding knowledge required!', 'wgl-extensions' ); ?></li>
		<li><svg class="icon"><use xlink:href="#checkmark-outline"></use></svg><?php esc_html_e( 'Add custom fields to taxonomies or user profile.', 'wgl-extensions' ); ?></li>
		<li><svg class="icon"><use xlink:href="#checkmark-outline"></use></svg><?php esc_html_e( 'Create custom settings pages.', 'wgl-extensions' ); ?></li>
		<li><svg class="icon"><use xlink:href="#checkmark-outline"></use></svg><?php esc_html_e( 'Create frontend submission forms.', 'wgl-extensions' ); ?></li>
		<li><svg class="icon"><use xlink:href="#checkmark-outline"></use></svg><?php esc_html_e( 'Save custom fields in custom tables.', 'wgl-extensions' ); ?></li>
		<li><svg class="icon"><use xlink:href="#checkmark-outline"></use></svg><?php esc_html_e( 'And much more!', 'wgl-extensions' ); ?></li>
	</ul>
	<a class="button button-primary" target="_blank" href="https://metabox.io/pricing/?utm_source=dashboard&utm_medium=link&utm_campaign=meta_box"><?php esc_html_e( 'Get Meta Box PRO now', 'wgl-extensions' ); ?></a>
</div>
<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
	<symbol id="checkmark-outline" viewBox="0 0 20 20">
		<path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM6.7 9.29L9 11.6l4.3-4.3 1.4 1.42L9 14.4l-3.7-3.7 1.4-1.42z"/>
	</symbol>
</svg>
